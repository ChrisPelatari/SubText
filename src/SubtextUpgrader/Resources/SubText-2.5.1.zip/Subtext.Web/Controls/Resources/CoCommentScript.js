 var blogTool = "{0}";
 var blogURL = "{1}";
 var blogTitle   = "{2}";
 var postTitle = "{3}";
 var postURL = "{4}";
 var commentAuthorFieldName = "{5}";
 var commentTextFieldName = "{6}";
 var commentButtonName  = "{7}";
 var commentFormID = "{8}";
 var commentAuthorLoggedIn = false;
 var cocomment_force  = false;
</script>
<script type="text/javascript" src="http://www.cocomment.com/js/cocomment.js">